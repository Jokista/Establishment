import VueQriously from 'vue-qriously'
export default async ({ Vue }) => {
  Vue.use(VueQriously)
}
